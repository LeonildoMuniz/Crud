﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Crud.Classes
{
    class ClassPessoa
    {
        public int id { get; set; }
        public string nome { get; set; }
        public string celular { get; set; }
        public string email { get; set; }
        public DateTime data { get; set; }



        public ClassPessoa()
        {
        }

        public List<ClassPessoa> ListaPessoa()
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            List<ClassPessoa> li = new List<ClassPessoa>();
            string sql = "SELECT * FROM Pessoa";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassPessoa p = new ClassPessoa();
                p.id = (int)dr["Id"];
                p.nome = dr["nome"].ToString();
                p.celular = dr["celular"].ToString();
                p.email = dr["email"].ToString();
                p.data = Convert.ToDateTime(dr["data"]);

                li.Add(p);
            }
            ClassConBanco.FecharConexao();
            return li;
        }

        public void Localizar(int id)
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            string sql = "SELECT * FROM Pessoa WHERE Id='" + id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                celular = dr["celular"].ToString();
                email = dr["email"].ToString();
                data = Convert.ToDateTime(dr["data"]);
            }

            ClassConBanco.FecharConexao();
        }

        public void Inserir(string nome, string celular, string email, DateTime data)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string dta = data.ToString("yyyy/MM/dd");
                string sql = "INSERT INTO Pessoa(nome, celular, email, data) VALUES  ('" + nome + "','" + celular + "','" + email + "','" + dta + "')";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();

                MessageBox.Show("Cadastro Efetuado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Editar(int id, string nome, string celular, string email, DateTime data)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string dta = data.ToString("yyyy/MM/dd");
                string sql = "UPDATE Pessoa SET nome='" + nome + "', celular = '" + celular + "', email = '" + email + "', data = '" + dta + "'  WHERE Id = '" + id + "'";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();
                MessageBox.Show("Cadastro Editado com Sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void Excluir(int id)
        {
            try
            {

                DialogResult confirma = MessageBox.Show("Tem certeza que deseja excluir?", "Atenção!", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);


                if (confirma.ToString().ToUpper() == "YES")
                {

                    SqlConnection con = ClassConBanco.ObterConexao();
                    string sql = "DELETE FROM Pessoa WHERE Id = '" + id + "'";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    ClassConBanco.FecharConexao();

                }
                else
                {
                    MessageBox.Show("Processo abortado!");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


    }
}
