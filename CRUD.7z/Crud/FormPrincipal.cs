﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Crud.Classes;

namespace Crud
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        public void CarregaDGV()
        {
            ClassPessoa pessoa = new ClassPessoa();
            dgvPessoa.DataSource = pessoa.ListaPessoa();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            CarregaDGV();
        }
        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            dataNasc.Value = DateTime.Now;
            txtId.Focus();
            CarregaDGV();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            ClassPessoa inserir = new ClassPessoa();
            inserir.Inserir(txtNome.Text, txtCelular.Text,txtEmail.Text,dataNasc.Value);
            txtId.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            dataNasc.Value = DateTime.Now;
            txtId.Focus();
            CarregaDGV();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            ClassPessoa excluir = new ClassPessoa();
            excluir.Excluir(Convert.ToInt32(txtId.Text));
            txtId.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            dataNasc.Value = DateTime.Now;
            txtId.Focus();
            CarregaDGV();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            ClassPessoa editar = new ClassPessoa();
            editar.Editar(Convert.ToInt32(txtId.Text), txtNome.Text, txtCelular.Text, txtEmail.Text, dataNasc.Value);
            txtId.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            dataNasc.Value = DateTime.Now;
            txtId.Focus();
            CarregaDGV();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            ClassPessoa localizar = new ClassPessoa();
            localizar.Localizar(Convert.ToInt32(txtId.Text));
            txtNome.Text = localizar.nome.Trim();
            txtEmail.Text = localizar.email.Trim();
            txtCelular.Text = localizar.celular.Trim();
            dataNasc.Value = localizar.data;
            CarregaDGV();
        }

        private void dgvPessoa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >=0)
            {
                DataGridViewRow row = this.dgvPessoa.Rows[e.RowIndex];
                txtId.Text = row.Cells[0].Value.ToString().Trim();
                txtNome.Text = row.Cells[1].Value.ToString().Trim();
                txtCelular.Text = row.Cells[2].Value.ToString().Trim();
                txtEmail.Text = row.Cells[3].Value.ToString().Trim();
                dataNasc.Value = Convert.ToDateTime(row.Cells[4].Value);
            }
        }
    }
}
